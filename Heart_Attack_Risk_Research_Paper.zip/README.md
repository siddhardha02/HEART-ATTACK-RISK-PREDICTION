# Heart Attack Risk Prediction from Retinal Fundus Images

LaTeX source of the paper "Heart Attack Risk Prediction from Retinal Fundus Images Using MobileNetV2 Transfer Learning with Cached Deep Features".

## Contents

- `main.tex` - full paper (IEEEtran conference format, bibliography included)
- `figures/` - put the figure images here (see below)

## Build

Upload the folder to Overleaf (or compile locally with `pdflatex main.tex`, run twice).

## Figures

Each figure in `main.tex` is currently a placeholder box. Save your images in `figures/` and replace each `\figbox{...}` line with the `\includegraphics` line written in the comment just above it, for example:

```latex
\includegraphics[width=\columnwidth]{figures/fig1_block_diagram.png}
```

Expected file names: `fig1_block_diagram.png`, `fig2_counts.png`, `fig3_metrics.png`, `fig4_confusion.png`, `fig5_curves.png`, `fig6_roc_pr.png`.
